<?php
include "header.php";
?>

<style>
.form-field{
	 width: 90%;
	 height: 20px;
	 border-radius: 5px;
	 background-color: #fbede6;
}
</style>
 
<div class="mainbg ">
<div class="container">
<div align="center">
<br />
<br />
  <h2>User Login</h2>
</div>
<div>

<div style="height: 300px; width: 50%;margin-left: 25%; margin-top: 4%; background-color:#fff2f2">
	
	<form  style="padding-top: 90px">
	<table width="80%" align="center" cellpadding="10px" >
	<tr>
	<td>name :  
	</td><td width="60%">	<input class="form-field" type="text" name="name">
		</td>
	</tr>
<tr>
<td>username :  
		</td><td><input class="form-field" type="text"  name="username">
		</td>
	</tr>
	
	<tr>
	<td>email :  
	</td><td width="60%">	<input class="form-field" type="text" name="email">
		</td>
	</tr>
<tr>
	<td>password :  
	</td><td width="60%">	<input class="form-field" type="text" name="password">
		</td>
	</tr>
include "header.php";
?>


