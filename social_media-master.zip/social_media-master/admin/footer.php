</div>
    <!-- /#wrapper -->

    <!-- jQuery -->
  
    <!-- Bootstrap Core JavaScript -->
    <script src="template/js/bootstrap.min.js"></script>

    <!-- Morris Charts JavaScript -->
   
</body>

</html>
