
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
          
		  
		  
		    <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
				  <li class="active">
                        <a href="index.html"><i class="fa fa-fw fa-dashboard"></i> Dashboard</a>
                    </li>
					
                    <li class="active">
                         <a href="javascript:;" data-toggle="collapse" data-target="#user"><i class="fa fa-fw fa-arrows-v"></i> User <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="user" class="collapse">
                            <li>
                                <a href="adduser.php">Add User</a>
                            </li>
							<li>
                                <a href="userlist.php">User List</a>
                            </li>
                        </ul>
			
					 
    
					  <a href="javascript:;" data-toggle="collapse" data-target="#state"><i class="fa fa-fw fa-arrows-v"></i> State <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="state" class="collapse">
                            <li>
                                <a href="addstate.php">Add State</a>
                            </li>
							<li>
                                <a href="statelist.php">State List</a>
                            </li>
                        </ul>
						  <a href="javascript:;" data-toggle="collapse" data-target="#district"><i class="fa fa-fw fa-arrows-v"></i> District <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="district" class="collapse">
                            <li>
                                <a href="adddistrict.php">Add District</a>
                            </li>
							<li>
                                <a href="districtlist.php">District List</a>
                            </li>
                        </ul>
					   <a href="javascript:;" data-toggle="collapse" data-target="#place"><i class="fa fa-fw fa-arrows-v"></i>Place <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="place" class="collapse">
                            <li>
                                <a href="addplace.php">Add Place</a>
                            </li>
							<li>
                                <a href="placelist.php">Place List</a>
                            </li>
                        </ul>
						 <a href="javascript:;" data-toggle="collapse" data-target="#friend"><i class="fa fa-fw fa-arrows-v"></i> Friend <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="friend" class="collapse">
                            <li>
                                <a href="addfriend.php">Add Friend</a>
                            </li>
							<li>
                                <a href="friendlist.php">Friend List</a>
                            </li>
                        </ul>
						<a href="javascript:;" data-toggle="collapse" data-target="#friend"><i class="fa fa-fw fa-arrows-v"></i> Retailer <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="retailer" class="collapse">
                            <li>
						 <a href="javascript:;" data-toggle="collapse" data-target="#updates"><i class="fa fa-fw fa-arrows-v"></i> Updates <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="updates" class="collapse">
                            <li>
                                <a href="addupdates.php">Add Updates</a>
                            </li>
							<li>
                                <a href="updateslist.php">Updates List</a>
                            </li>
                        </ul>
						 <a href="javascript:;" data-toggle="collapse" data-target="#like"><i class="fa fa-fw fa-arrows-v"></i> Like <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="like" class="collapse">
                            <li>
                                <a href="addlike.php">Add Like</a>
                            </li>
							<li>
                                <a href="likelist.php">Like List</a>
                            </li>
                        </ul>
						 <a href="javascript:;" data-toggle="collapse" data-target="#comment"><i class="fa fa-fw fa-arrows-v"></i> Comment <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="comment" class="collapse">
                            <li>
                                <a href="addcomment.php">Add comment</a>
                            </li>
							<li>
                                <a href="commentlist.php">Comment List</a>
                            </li>
                        </ul>
						 <a href="javascript:;" data-toggle="collapse" data-target="#category"><i class="fa fa-fw fa-arrows-v"></i> Category <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="district" class="collapse">
                            <li>
                                <a href="addcategory.php">Add Category</a>
                            </li>
							<li>
                                <a href="categorylist.php">Category List</a>
                            </li>
                        </ul>
						 <a href="javascript:;" data-toggle="collapse" data-target="#share"><i class="fa fa-fw fa-arrows-v"></i> Share <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="share" class="collapse">
                            <li>
                                <a href="addshare.php">Add Share</a>
                            </li>
							<li>
                                <a href="sharelist.php">Share List</a>
                            </li>
                        </ul>
						 <a href="javascript:;" data-toggle="collapse" data-target="#reward"><i class="fa fa-fw fa-arrows-v"></i> Reward <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="reward" class="collapse">
                            <li>
                                <a href="addreward.php">Add Reward</a>
                            </li>
							<li>
                                <a href="rewardlist.php">Reward List</a>
                            </li>
                        </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>
		
		
		
		

<!--end of the header-->