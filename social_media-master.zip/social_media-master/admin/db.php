<?php
$con=mysqli_connect("localhost","root","","social") or die("unable to connect the database");
?>
